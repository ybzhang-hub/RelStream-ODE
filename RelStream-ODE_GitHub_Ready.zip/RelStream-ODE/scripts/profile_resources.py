"""Measure serialized training, validation, inference and allocator memory."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from relstream_ode.benchmark import main

if __name__ == "__main__":
    main()
